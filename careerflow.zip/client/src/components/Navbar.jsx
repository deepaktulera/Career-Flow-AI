import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Menu, X } from 'lucide-react'

const Navbar = () => {
  const [open, setOpen] = useState(false)

  const closeMenu = () => {
    setOpen(false)
  }

  return (
    <nav className="sticky top-0 z-50 w-full bg-white shadow-sm">
      <div className="flex items-center justify-between p-4 lg:px-10">

        {/* Logo */}
        <div>
          <img src="" alt="app_logo" />
          <span className="font-bold text-blue-600">
            CareerFlow AI
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:block">
          <ol className="flex items-center gap-6 text-lg">

            <li>
              <Link to="/">AI Resume Builder</Link>
            </li>

            <li>
              <select className="bg-transparent outline-none">
                <option value="">Features</option>
                <option value="resume">Resume Builder</option>
                <option value="tracking">Job Tracking</option>
              </select>
            </li>

            <li>
              <select className="bg-transparent outline-none">
                <option value="">Services</option>
                <option value="resume-review">Resume Review</option>
                <option value="career">Career Guidance</option>
              </select>
            </li>

            <li>
              <Link to="/">Human Data</Link>
            </li>

          </ol>
        </div>

        {/* Desktop Auth Buttons */}
        <div className="hidden lg:flex items-center gap-4">
          <Link to="/login">
            LOG IN
          </Link>

          <Link
            className="rounded bg-blue-600 px-4 py-2 text-white"
            to="/register"
          >
            SIGN UP
          </Link>
        </div>

        {/* Mobile Hamburger Button */}
        <button
          className="lg:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>

      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="absolute w-full flex flex-col gap-5 border-t bg-white p-6 lg:hidden">

          <Link
            to="/"
            onClick={closeMenu}
          >
            AI Resume Builder
          </Link>

          <Link
            to="/"
            onClick={closeMenu}
          >
            Features
          </Link>

          <Link
            to="/"
            onClick={closeMenu}
          >
            Services
          </Link>

          <Link
            to="/"
            onClick={closeMenu}
          >
            Human Data
          </Link>

          <hr />

          <Link
            to="/login"
            onClick={closeMenu}
          >
            LOG IN
          </Link>

          <Link
            className="rounded bg-blue-600 px-4 py-3 text-center text-white"
            to="/register"
            onClick={closeMenu}
          >
            SIGN UP
          </Link>

        </div>
      )}
    </nav>
  )
}

export default Navbar