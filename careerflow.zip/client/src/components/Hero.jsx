import React, { useEffect, useRef } from 'react'

const Hero = () => {
    const canvasRef = useRef(null)

    useEffect(() => {
        const canvas = canvasRef.current
        const ctx = canvas.getContext('2d')

        const drawGradient = () => {
            canvas.width = canvas.offsetWidth
            canvas.height = canvas.offsetHeight

            const bg = ctx.createLinearGradient(
                0,
                0,
                canvas.width,
                canvas.height
            )

            bg.addColorStop(0, '#ffffff')
            bg.addColorStop(0.45, '#dbeafe')
            bg.addColorStop(0.75, '#93c5fd')
            bg.addColorStop(1, '#2563eb')

            ctx.fillStyle = bg
            ctx.fillRect(0, 0, canvas.width, canvas.height)
        }

        drawGradient()

        window.addEventListener('resize', drawGradient)

        return () => {
            window.removeEventListener('resize', drawGradient)
        }
    }, [])

    return (
        <section className="relative mx-auto overflow-hidden">

            <canvas
                ref={canvasRef}
                className="absolute inset-0 z-0 h-full w-full"
            />

            <div className="relative z-10 mx-auto flex min-h-[380px] xl:min-h-screen max-w-4xl flex-col items-center justify-center gap-5 px-6 py-12 text-center animate-fadeIn">

                <h3 className="font-semibold text-blue-700">
                    Trusted by OVER 1.2 million JOB SEEKERS!
                </h3>

                <h1 className="max-w-3xl text-4xl font-bold text-slate-900 md:text-6xl">
                    Land your dream job. Without the stress.
                </h1>

                <div className="flex flex-col gap-3 text-lg text-slate-700 md:flex-row md:gap-8">
                    <span>AI Resume Builder</span>
                    <span>Automated Job Tracking</span>
                    <span>Optimize your LinkedIn profile</span>
                    <span>And much more...</span>
                </div>

                <button className="mt-3 rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white transition hover:bg-blue-700">
                    SIGN UP FOR FREE
                </button>

                <p className="mt-3 max-w-lg text-sm text-slate-600">
                    "I got recruiters from Amazon, Wise, and other companies reaching
                    out to me already!!"
                </p>

            </div>
        </section>
    )
}

export default Hero