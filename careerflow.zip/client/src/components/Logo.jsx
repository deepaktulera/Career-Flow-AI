import React from 'react'

const Logo = () => {
  const companies = [
    {
      name: 'Google',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e821d2faa9faa65fed_google%20logo.svg'
    },
    {
      name: 'Meta',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6811c93cc92136775a2cec23_Meta-logo.svg'
    },
    {
      name: 'Netflix',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e8faaba964c83a21f0_netflix%20logo.svg'
    },
    {
      name: 'Amazon',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e8c9137787965280b0_Amazon%20logo.svg'
    },
    {
      name: 'Airbnb',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e8d0de636763a1eb11_airbnb%20logo.svg'
    },
    {
      name: 'Spotify',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e9ecc95379c6f5706a_spotify%20logo.svg'
    },
    {
      name: 'Tesla',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e8dbafd8468a1132a6_Tesla%20logo.svg'
    },
    {
      name: 'Bloomberg',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e8a27aa6ba0cf2f078_Bloomberg%20logo.svg'
    },
    {
      name: 'Microsoft',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e94fc9e5207a9b7823_microsoft%20logo.svg'
    },
    {
      name: 'Adobe',
      logo: 'https://cdn.prod.website-files.com/635c591378332f38be25d45f/6720f0e87ca320857f7eb230_adobe-logo.svg'
    }
  ]

  return (
    <section className="relative overflow-hidden bg-white py-20">

      {/* Heading */}
      <div className="mx-auto mb-12 max-w-3xl px-6 text-center">

        <span className="rounded-full bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-600">
          SUCCESS STORIES
        </span>

        <h2 className="mt-5 text-3xl font-bold text-slate-900 md:text-5xl">
          Trusted by job seekers who've landed at
          <span className="text-blue-600"> top companies</span>
        </h2>

        <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-slate-600 md:text-lg">
          Our users have secured positions at industry-leading companies such as
        </p>

      </div>

      {/* Logo Marquee */}
      <div className="relative w-full overflow-hidden">

        <div className="flex animate-marquee gap-10 whitespace-nowrap">

          {/* First Set */}
          {companies.map((company) => (
            <div
              key={company.name}
              className="flex h-24 min-w-44 items-center justify-center rounded-xl border border-slate-100 bg-white px-8 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
            >
              <img
                src={company.logo}
                alt={`${company.name} logo`}
                className="max-h-10 max-w-28 object-contain"
              />
            </div>
          ))}

          {/* Duplicate for Infinite Effect */}
          {companies.map((company) => (
            <div
              key={`${company.name}-duplicate`}
              className="flex h-24 min-w-44 items-center justify-center rounded-xl border border-slate-100 bg-white px-8 shadow-sm"
            >
              <img
                src={company.logo}
                alt={`${company.name} logo`}
                className="max-h-10 max-w-28 object-contain"
              />
            </div>
          ))}

        </div>

      </div>

    </section>
  )
}

export default Logo