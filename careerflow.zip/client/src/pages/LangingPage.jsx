import Navbar from '../components/Navbar'
import Hero from '../components/Hero'
import Logo from '../components/Logo'

const LandingPage = () => {
  return (
    <div className="min-h-screen overflow-hidden">
      <Navbar />

      <main>
        <Hero />
      </main>

      <Logo />
    </div>
  )
}

export default LandingPage